package Banco;

import javax.sound.midi.Receiver;

public class C_Ahorros extends Cuenta {
	
	public C_Ahorros(int numCuenta, int clave, double saldo, Cliente cliente, boolean tieneFiducia, boolean tieneCDT) {
		super(numCuenta, clave, saldo, cliente, tieneFiducia, tieneCDT);
	
	}


	
}
