package Banco;

public class ValorException extends Exception {

	public ValorException(String string) {
		// TODO Auto-generated constructor stub
	}

}
