package Banco;

public class NumCuenException extends Exception {

	public NumCuenException(String string) {
            
	}

}